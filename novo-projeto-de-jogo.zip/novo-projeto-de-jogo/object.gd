extends Node3D; class_name ObjectInteractable


# Called when the node enters the scene tree for the first time.
func _interact():
	print("oi")
