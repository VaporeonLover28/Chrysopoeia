extends CharacterBody3D


const SPEED = 5.0
const JUMP_VELOCITY = 4.5

@onready var camera: Node3D = $pivot
@onready var cam_pivot: Camera3D = $pivot/Camera3D
@onready var ray_cast_3d: RayCast3D = $pivot/Camera3D/RayCast3D


@export var velocidade = 5.0
@export var aceleracao = 4.0
@export var forca_pulo = 4.5
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")


func _unhandled_input(event): 
	if event is InputEventMouseMotion: # se o jogador mover o mouse(prendemos ele na tela)
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
		cam_pivot.rotate_y(-event.relative.x * 0.01)
		camera.rotate_x(-event.relative.y * 0.01)
		camera.rotation.x = clamp(camera.rotation.x, deg_to_rad(-30), deg_to_rad(60))
		
		


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity.y -= gravity * delta # aplicando a gravidade ao jogador
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = forca_pulo # pulo
		#Vector2(x,y)
	var input = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var dir = (cam_pivot.transform.basis * Vector3(input.x, 0, input.y)).normalized() #guardando os inputs
			#mantendo a rotação * direção do input .normalizando o vetor 3
	velocity.x = lerp(velocity.x, dir.x * velocidade, aceleracao * delta)#movendo no x
	velocity.z = lerp(velocity.z, dir.z * velocidade, aceleracao * delta)#movendo no z
	
	
	
	move_and_slide() #aplicando a velocidade 
